#!/bin/bash


GAME_JAR=unruly.jar
gptk_filename="sgt.gptk"

myscript=$(realpath "$0")
mydir=$(dirname "$myscript")
cd "$mydir"
source ./launch.shellscript
exit

