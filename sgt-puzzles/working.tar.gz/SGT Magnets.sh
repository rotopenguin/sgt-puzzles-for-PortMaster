#!/bin/bash


GAME_JAR=magnets.jar
gptk_filename="sgt.gptk"

myscript=$(realpath "$0")
mydir=$(dirname "$myscript")
cd "$mydir"
source ./launch.shellscript
exit

